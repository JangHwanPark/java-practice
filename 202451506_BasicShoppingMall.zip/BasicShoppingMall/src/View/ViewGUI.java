package src.View;

// GUI Interface
public class ViewGUI {

}